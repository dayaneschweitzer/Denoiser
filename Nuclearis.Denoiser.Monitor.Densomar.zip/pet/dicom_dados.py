"""
Classe para o armazenamento dos dados Dicom.
"""

class Dados:
    def __init__(self,ds,path_save,arq_name):
        #Dicom file
        self.ds = ds
        #Localização do slice através da tag dicom (0020, 1041)
        #Imagens do respectivo slice
        self.imagem = ds.pixel_array
        #Parte do caminho para o salvamente dos dados
        self.path_save = path_save 
        #Nome do arquivo
        self.arq_name = arq_name

    def getDs(self):
        return self.ds


    def getImagem(self):
        return self.imagem

    def getPath(self):
        return self.path_save 

    def getName(self):
        return self.arq_name

