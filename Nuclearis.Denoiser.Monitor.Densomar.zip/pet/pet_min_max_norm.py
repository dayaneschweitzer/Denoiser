import numpy as np


class MinMaxNorm:
    """
    MinMaxNorm - Classe responsável pela Normalizção min max das imagens.
        
    """
    
    def __init__(self):
        self.max = 0

    def fit_transform(self,images):
        """
        Busca o valor maximo dos dados, salva o valor e retorna o conjunto de imagens normalizado entre 0 e 1.
            Args:
                Image:Matrix de images - Lista no formato de matriz que representa as imagens que vão ser normalizada.
                
            Return: 
                Imagens Normalizdas entre 0 e 1.
        """
        
        self.max = np.asarray(images).max()
        return np.asarray(images)/self.max

    def transform(self,images):
        """
        Transforma o conjunto de imagens em valores entre 0 e 1.
            Args:
                Image:Matrix de images - Lista no formato de matriz que representa as imagens que vão ser normalizada.
                
            Return: 
                Imagens Normalizdas entre 0 e 1.
        """
    
        return np.asarray(images)/self.max
    
    def inverse_transform(self,images):
        """
        Transforma o conjunto de imagens em seus valores originais.
            Args:
                Image:Matrix de images - Lista no formato de matriz que representa as imagens.
                
            Return: 
                Imagens com seus valores originais.
        """
        
        return np.asarray(images)*self.max
    
    def save(self,name="pet/config/_scaler.txt"):
        f = open(name, "a")
        f.write(str(self.max))
        f.close()
    
    def load(self,name="pet/config/_scaler.txt"):
        f = open(name, "r")
        self.max = int(f.read())
        f.close()
