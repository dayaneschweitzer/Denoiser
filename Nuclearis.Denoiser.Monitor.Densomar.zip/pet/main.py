import os
import pydicom
import gc
import tensorflow as tf
from pet.pet_min_max_norm import MinMaxNorm
from pet.pet_model import Modelo
from pet.utils import Utils
from pet.dicom_dados import Dados
from pet.upload import envio_de_imagem_ao_dmc4chee

vr_binarios = {'OB', 'OW', 'OF', 'SQ', 'UN'}

def process_folder(path_exames):
    path_model_deno = 'pet/model/EXP02_02_16frame_Fine_Tuning_.h5' # Peso para remoção do ruido
    path_model_sino = 'pet/model/EXP02_02__Refino_01_Fine_Tuning_.h5' # Peso para correção de contraste
    modelo_arqui = 'pet/model/modelo.json'
    modelo_arqui_corre = 'pet/model/model_corre.json'
    save_folder = os.environ.get('PET_OUTPUT_PATH')
    print(f'Pasta de salvamento {save_folder}')

    scaler  = MinMaxNorm()
    scaler.load()
    print('Scaler carregado')

    modelo_pet = Modelo(path_model_deno,path_model_sino,modelo_arqui, modelo_arqui_corre)
    print('Modelo carregado')

    ultis = Utils()
    paths = ultis.files_path(path_exames)
    print(f'Arquivos encontrados na pasta {path_exames}: {len(paths)}')
    output_study = path_exames.split("/")[-1]
    print(f'ID de estudo: {output_study}')
    dicoms = []

    for path in paths:
        ds = pydicom.read_file(path, force=True)
        path_save = os.path.dirname(path)
        file_name = path.split("/")[-1]
        dicoms.append(Dados(ds,path_save,file_name))
        

    quant_exames = len(dicoms)
    slice_near = 3
    cropx = 128
    cropy = 128
    root = "1.2.345.6.6.890123.4.567."
    study = pydicom.uid.generate_uid(root)
    serie = pydicom.uid.generate_uid(root)
    print(f'Dicoms encontrados: {len(dicoms)}')
    for idx, exame in enumerate(dicoms):
        ds = exame.getDs()
        if idx<=slice_near or idx >= quant_exames-slice_near:
            print(f'Criando pasta {save_folder + exame.getPath()}')
            ultis.criacaoPasta(save_folder+exame.getPath())
            ds = modelo_pet.change_uids(ds)
            ds.save_as(save_folder+"/"+exame.getPath()+"/"+exame.getName())
            print('Realizando predicao...')
            path_result = path_save + "/" + file_name
            ds = modelo_pet.predicao(path_result, scaler, path_save = 'pet/result')

    del modelo_pet

    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()

    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()

    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()
    tf.keras.backend.clear_session()
    gc.collect()

    envio_de_imagem_ao_dmc4chee(save_folder)
