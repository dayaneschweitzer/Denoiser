import tensorflow as tf
import pydicom
import numpy as np


class  Modelo:
    

    def __init__(self,path_model_deno,path_model_sino, modelo_arqui,modelo_arqui_corre):
         
        """

            Args:
                path_model_deno:String - Caminnho para os pesos do modelo de remoção de ruído.
                path_model_sino:String - Caminnho para os pesos do modelo de correção de contraste.
                
                modelo_arqui:Json - Json com as informações para montagem da arquitetura de remoção de ruído.
                modelo_arqui_corre:Json - Json com as informações para montagem da arquitetura de correção de contraste.
                

            Return: 
        """
        
        
        json_file = open(modelo_arqui, 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        
        #Carregamento do Modelo Denoising
        self.model_deno = tf.keras.models.model_from_json(loaded_model_json)
        self.model_deno.load_weights(path_model_deno)
        
        #Carregamento do Modelo Correção de Constraste
        
        
        
        json_file = open(modelo_arqui_corre, 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        
        self.model_sino = tf.keras.models.model_from_json(loaded_model_json)
        self.model_sino.load_weights(path_model_sino)
    
    
    def change_uids(self,ds):
        
        """
            Recebe um exame no  formato dicom e altera o cabeçalho:SOP Instance UID,
            Study Instance UID, Series Instance UID  e Frame of Reference UID.

            Args:
                ds:pydicom.dataset.FileDataset - Arquivo dicom que vai ter a modificação

            Return: 
                ds:pydicom.dataset.FileDataset - Arquivo dicom modificado.
        """
        #Todo exame vai ter esse prefixo
        root = "1.5.428.6.6.695432.3.507."
        #(0008, 0018) SOP Instance UID  
        ds[('0008','0018')].value = pydicom.uid.generate_uid(root)
        #(0020, 000d) Study Instance UID
        #ds[('0020','000d')].value = pydicom.uid.generate_uid(root)
        #(0020, 000e) Series Instance UID 
        ds[('0020','000e')].value = pydicom.uid.generate_uid(root)
        #(0020, 0052) Frame of Reference UID
        #ds[('0020','0052')].value = pydicom.uid.generate_uid(root)
        
        
        #-----------NOVO------------
        
        #(0008, 103e) Series Description
        ds[('0008', '103e')].value = "Denoising "+ ds[('0008', '103e')].value
        
        #-----------NOVO END------------
        
        
        return ds

        
                
    def predicao(self,path_exame,scaler,path_save="tmp"):
        
        """
            Recebe um exame e a versão dele sem ruído.

            Args:
                path_exame:String - Caminnho onde está o exame que vai ter a remoção do ruído.
                scaler:MinMaxNorm - Normalizador de dados min max 0 e 1 para das redes de denoising e refino.
                path_save:String - Caminh onde será salvo o exame com remoção do ruído.

            Return: 
        """
        #Nome final do arquivo que vai ser salva
        """
            Para a API isso provavelmente deve ser alterado.
        """
        filename = path_exame.split("/")[-1]
        
        #tamanho da imagem
        IMG_WIDTH = 64
        IMG_HEIGHT =64
        MAX_PROJ = 64

        
        #Quantidade de imagens de entrada da rede
        PROJ_QUANT_IN = 1
        PROJ_QUANT_IN_CROP = 1
        #Quantidade de imagen de saida da Rede
        PROJ_QUANT_OUT = 1
        
                
        """
        ds_x.pixel_array - Contém  os valores dos pixels do exame
        Para Exame de SPCET o formato é Projeções x Altura da imagem x Largura da Imagem
        """
        #leitura do arquivo Dicom que vai passar pela remoção de ruído
        ds_x = pydicom.read_file(path_exame)
        #Alteração do cabeçalho
        ds_x = self.change_uids(ds_x)
        
        #-------Predição Denoising------------
        
        
        #lista onde ficara salva o exame sem ruído
        pred = []
        #Imagem apenas com a regição de interesse
        imgs_x = ds_x.pixel_array

        
        #Fazendo a remoção de ruído para cada projeção
        for i in range(len(imgs_x)):
            image = imgs_x[i].reshape(IMG_WIDTH,IMG_HEIGHT).copy()
            
        
            #-----------NOVO------------

            image[image>scaler.max] = scaler.max

            #-----------NOVO END------------
            
            image = scaler.transform(image)


            mix_image = np.zeros((1,IMG_WIDTH,IMG_HEIGHT,PROJ_QUANT_IN))
            for idx in range(PROJ_QUANT_IN):
                mix_image[0,:,:,idx] = np.asarray(image)

            sr_img = self.model_deno.predict(mix_image,verbose = 0)
            sr_img = scaler.inverse_transform(tf.squeeze(sr_img))
            sr_img[sr_img <0] = 0
            pred.append(sr_img)

            imgs_x[i] = pred[i]
        
        
    
        #-------Predição Refinamento dos projeções------------

        pred = []

        for i in range(len(imgs_x)):
            teste_image = imgs_x[i].reshape(1,IMG_WIDTH,IMG_HEIGHT,1).copy()
            teste_image[teste_image>scaler.max] = scaler.max
            teste_image2 = scaler.transform(teste_image)

            sr_img = self.model_sino.predict(teste_image2,verbose = 0)
            sr_img = scaler.inverse_transform(tf.squeeze(sr_img))
            #sr_img = rev_log(tf.squeeze(sr_img))
            sr_img[sr_img <0] = 0
            pred.append(sr_img)

            imgs_x[i] = pred[i]
        
        #-------Salvando Exame com a Remoção de Ruído------------
        
        #Salvando os novos valores de pixels do exame no dicom
        ds_x.PixelData = imgs_x

        
        #Salvando o novo dicom no caminho escolhido
        ds_x.save_as(path_save+"/"+"Corrigido_"+filename)  


    