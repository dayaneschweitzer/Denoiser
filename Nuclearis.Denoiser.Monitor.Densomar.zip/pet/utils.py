import os

"""
Classe para realizar operações diversas (classe faz tudo)
"""

class Utils: 

    def __init__(self):
        pass


    def files_path(self,path):
        
        """
        Busca todos os arquivos dentro das pastas e subpastas.
        
        Args:
            path:str - String que contém o path para a a pasta raiz.
            
        Return: 
            infos:list - Lista contendo todos os caminhos para todos os arquivos.
        """
    
        infos =[]
        abs_path = os.path.abspath(path)
        for p, _, files in os.walk(abs_path):
            for file in files:
                infos.append(os.path.join(p, file))
        return infos
    
    def criacaoPasta(self,path):
                
        """
        Verfica se já existe uma pasta, se não existe ele cria.
        
        Args:
            path:str - String que contém o path para a a pasta.
            
        Return: 
            
        """
        if not os.path.exists(path):
            os.makedirs(path)
            print(f'Pasta criada: {path}')
