import os
import pydicom
import shutil
from pynetdicom import AE
from pet.dicom_dados import Dados
from pet.utils import Utils

CLIENT = os.environ.get('NUCLEARIS_CLIENT_IP')

def envio_de_imagem_ao_dmc4chee(study_path):
    client_ip = CLIENT
    ultis = Utils()
    paths = ultis.files_path(study_path)
    dicoms = []

    # Carrega todos os arquivos DICOM em objetos Dados
    for path in paths:
        try:
            ds = pydicom.read_file(path, force=True)
            path_save = os.path.dirname(path)
            file_name = os.path.basename(path)
            dicoms.append(Dados(ds, path_save, file_name))
        except Exception as e:
            print(f'Erro ao carregar o arquivo DICOM {path}: {e}')
            continue

    if not dicoms:
        print('Nenhum arquivo DICOM foi carregado.')
        return

    # Cria a aplicação DICOM e adiciona contextos de apresentação
    ae = AE()
    sop_classes = set()

    # Adiciona todos os contextos de apresentação necessários
    for exame in dicoms:
        ds = exame.getDs()
        sop_class_name = ds.SOPClassUID
        sop_classes.add(sop_class_name)
    
    for sop_class_name in sop_classes:
        ae.add_requested_context(sop_class_name)
    
    # Contexto DICOM básico necessário
    ae.add_requested_context('1.2.840.10008.1.1')  # Comunicação DICOM básica
    
    pacs_port = 11112
    assoc = ae.associate(client_ip, pacs_port, ae_title="DCM4CHEE")

    if assoc.is_established:
        print('Associação estabelecida com sucesso.')
        first_exame = dicoms[0]
        ds = first_exame.getDs()
        status = assoc.send_c_store(ds)
        if status.Status in [0x0000, 0x0001]:
            print(f'Imagem {first_exame.getName()} enviada com sucesso.')
        else:
            print(f'Falha ao enviar imagem {first_exame.getName()} com status: {status.Status}')

        assoc.release()
        print('Associação liberada.')
    else:
        print('A comunicação falhou', client_ip, pacs_port)

    # Remove o conteúdo da pasta study_path, mas mantém a pasta em si
    for item in os.listdir(study_path):
        item_path = os.path.join(study_path, item)
        if os.path.isdir(item_path):
            shutil.rmtree(item_path)
        elif os.path.isfile(item_path) or os.path.islink(item_path):
            os.remove(item_path)
